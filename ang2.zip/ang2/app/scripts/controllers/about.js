'use strict';

/**
 * @ngdoc function
 * @name ang2App.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the ang2App
 */
angular.module('ang2App')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
